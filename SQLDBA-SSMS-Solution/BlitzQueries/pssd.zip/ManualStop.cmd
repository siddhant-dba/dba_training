setlocal ENABLEEXTENSIONS
set LaunchDir=%~dp0
rem stoping profile trace
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\internal\TUL1CIPEDB2_MSSQLSERVER_sp_trace_stop.out" -Q"EXEC tempdb.dbo.sp_trace13 'OFF',@AppName='SQLDIAG_TUL1CIPEDB2_MSSQLSERVER',@TraceName='tsqltrace'"
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_get_dbccloginfo.sql.out" -i"%launchdir%\get_dbccloginfo.sql"
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_RestoreTraceFlagOrigValues.out" -Q"EXEC tempdb.dbo.sp_diag_trace_flag_restore '%appname%'"
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_SQL Server Perf Stats Snapshot.sql.out" -i"%launchdir%\SQL Server Perf Stats Snapshot.sql"
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_Stopping Event Session.out" -Q"ALTER EVENT SESSION [pssdiag_xevent]  ON SERVER STATE = stop;DROP EVENT SESSION [pssdiag_xevent] ON SERVER;"
logman stop pssdiagperfmon
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_kill.out" -Q tempdb.dbo.sp_killpssdiagSessions
