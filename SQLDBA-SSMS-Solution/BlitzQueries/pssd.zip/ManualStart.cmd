setlocal ENABLEEXTENSIONS
set LaunchDir=%~dp0
md "%LaunchDir%\output\internal"
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_msdiagprocs.out" -i"%launchdir%\msdiagprocs.sql"
rem starting profiler trace
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\internal\TUL1CIPEDB2_MSSQLSERVER_sp_trace_start.out" -Q"EXEC tempdb.dbo.sp_trace13 'ON', @Events='138,161,140,160,196,78,74,76,53,70,75,77,92,94,167,93,95,16,193,212,137,214,21,33,127,67,55,79,80,69,162,157,148,60,189,61,58,217,218,190,115,158,159,116,14,20,15,18,195,81,150,17,216,215,100,10,11,182,186,184,188,187,192,71,12,13,166,73',@AppName='SQLDIAG_TUL1CIPEDB2_MSSQLSERVER',@FileName='%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_sp_trace', @MaxFileSize=500, @FileCount=50"
rem group: MSInfo
rem group: My Custom Collector
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_My Collector Script.sql.out" -i"%launchdir%\My Collector Script.sql"
rem group: SQL Base
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_MiscPssdiagInfo.sql.out" -i"%launchdir%\MiscPssdiagInfo.sql"
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_TraceFlagHelperProcs.tem.out" -i"%launchdir%\TraceFlagHelperProcs.tem"
rem group: SQL Server Perf Stats
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_SQL Server Perf Stats.sql.out" -i"%launchdir%\SQL Server Perf Stats.sql"
Start SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_SQL Server Perf Stats Snapshot.sql.out" -i"%launchdir%\SQL Server Perf Stats Snapshot.sql"
rem group: XEvent
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_pssdiag_xevent.sql.out" -i"%launchdir%\pssdiag_xevent.sql"
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_Add File Target.out" -Q"alter EVENT SESSION [pssdiag_xevent] ON SERVER   ADD TARGET package0.event_file(SET filename=N'%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_pssdiag_xevent.xel', max_file_size=(500), max_rollover_files=(50));"
SQLCMD.exe -STUL1CIPEDB2 -E -Hpssdiag -w4000 -o"%launchdir%output\TUL1CIPEDB2_MSSQLSERVER_Starting Event Session.out" -Q"ALTER EVENT SESSION [pssdiag_xevent]  ON SERVER STATE = start;"
rem starting Perfmon
logman stop pssdiagperfmon
logman delete pssdiagperfmon
logman CREATE COUNTER -n pssdiagperfmon -s TUL1CIPEDB2 -cf LogmanConfig.txt -f bin -si 00:00:15 -o output\pssdiag.blg -ow 
logman start pssdiagperfmon 
